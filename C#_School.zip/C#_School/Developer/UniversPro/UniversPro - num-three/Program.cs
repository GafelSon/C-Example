﻿// Fig. 1.3: Program.cs
// TExt-displaying app.
using System;

class Program
{
    // Main method begins execution of C# app
    static void Main()
    {
        int number_one;
        int number_two;
        int sum, sub, mul, div, rem;

        Console.Write("\n(O_O) Enter Your First Number : "); // prompt user
        // read first number from user
        number_one = int.Parse(Console.ReadLine()); 

        Console.Write("\n(O_O) Enter Your Second Number : "); // prompt user
        // read second number from user
        number_two = int.Parse(Console.ReadLine());

        sum = number_one + number_two; // Addition numbers
        sub = number_one - number_two; // Subtraction numbers
        mul = number_one * number_two; // Multiplication numbers
        div = number_one / number_two; // Division numbers
        rem = number_one % number_two; // Remainder numbers

        Console.Write($"\n\t| Your Answer in Addition        Is : {sum}"); // display sum
        Console.Write($"\n\t| Your Answer in Subtraction     Is : {sub}"); // display sub
        Console.Write($"\n\t| Your Answer in Multiplication  Is : {mul}"); // display mul
        Console.Write($"\n\t| Your Answer in Division        Is : {div}"); // display div
        Console.WriteLine($"\n\t| Your Answer in Remainder       Is : {rem}"); // display rem

        // To not close the terminal
        Console.ReadKey();
    } // Main
} // end class Program

// Made by $oh@i1