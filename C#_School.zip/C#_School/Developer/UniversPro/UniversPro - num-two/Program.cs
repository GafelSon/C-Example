﻿// Fig. 1.2: Program.cs
// TExt-displaying app.
using System;

class Program
{
    // Main method begins execution of C# app
    static void Main()
    {
        string person = "Soheil"; // variable that stores the string "Soheil"
        Console.WriteLine($"Welcome to C# Programming, {person}!");

        // Console.WriteLine("1 and \n2 and \n3. yesCut"); //Test Part "\n"
        // Console.WriteLine("\t One tab space!"); //Test Part "\t"

        // To not close the terminal
        Console.ReadKey();
    } // Main
} // end class Program




/* ( [\n] ) -> For going to the next line.
 * ( [\t] ) -> For going to the next line. */

// Made by $oh@i1