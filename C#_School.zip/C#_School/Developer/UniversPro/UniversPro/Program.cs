﻿// Fig. 1.1: Program.cs
// TExt-displaying app.
using System;

class Program
{
    // Main method begins execution of C# app
    static void Main()
    {
        Console.WriteLine("Welcome to C# Programming!");
        Console.Write("Hello World!");

        // To not close the terminal
        Console.ReadKey();
    } // Main
} // end class Program


// Made by $oh@i1
